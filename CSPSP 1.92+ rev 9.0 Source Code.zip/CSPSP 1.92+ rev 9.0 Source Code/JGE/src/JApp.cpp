//-------------------------------------------------------------------------------------
//
// JGE++ is a hardware accelerated 2D game SDK for PSP/Windows.
//
// Licensed under the BSD license, see LICENSE in JGE root for details.
// 
// Copyright (c) 2007 James Hui (a.k.a. Dr.Watson) <jhkhui@gmail.com>
// 
//-------------------------------------------------------------------------------------

#include "../include/JApp.h"
#include "../include/JGE.h"


JApp::JApp()
{
	//mEngine = JGE::GetInstance();
	//mEngine->SetApp(this);
}


JApp::~JApp() 
{
}

// 
// JGE* JApp::GetJGE()
// { 
// 	return mEngine; 
// }
